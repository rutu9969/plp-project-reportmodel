import { MaterialModule } from './material.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ReportComponent } from './report/report.component';

import {MatInputModule} from '@angular/material/input';
import { MatCardModule, MatFormFieldModule } from '@angular/material';
import { AddreportComponent } from './addreport/addreport.component';
import { FormsModule } from '@angular/forms';
import {MatListModule} from '@angular/material/list';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatToolbarModule} from '@angular/material/toolbar';



@NgModule({
  declarations: [
    AppComponent,
    ReportComponent,

    AddreportComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    MatInputModule,
     MatCardModule,
     MatFormFieldModule,
     FormsModule,
     MatToolbarModule,
     MatListModule,
     MatGridListModule
  ],
  exports:[
     MatCardModule,
     MatInputModule,
     MatFormFieldModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
