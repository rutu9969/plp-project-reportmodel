import { Component, OnInit } from '@angular/core';
import { ReportModel } from '../model/reportmodel';
import { Router } from '@angular/router';
import { ReportService } from '../service/report.service';

@Component({
  selector: 'app-addreport',
  templateUrl: './addreport.component.html',
  styleUrls: ['./addreport.component.css']
})
export class AddreportComponent implements OnInit {

  allReports: ReportModel[];
  
  constructor(private router: Router, private reportService: ReportService) {
    this.allReports = [];
    this.allReports = this.reportService.display();
  }

  ngOnInit() {
  }

}
